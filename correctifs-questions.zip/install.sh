#!/usr/bin/env bash
# Usage : ./install.sh ~/Documents/examplay-web
set -euo pipefail
DEST="${1:-$HOME/Documents/examplay-web}"
cp supabase/migrations/*.sql "$DEST/supabase/migrations/"
echo "Migrations copiées dans $DEST/supabase/migrations"
cd "$DEST" && supabase db push
