-- Corrections des bugs critiques

-- ① (retiré) Le profil de l'admin n'est PAS recréé : il reste hors des classements.
--    La demande contributeur ne dépend plus du profil (voir 20261016).

-- ② Corriger les politiques RLS de contributor_applications pour INSERT
-- Le problème : la vérification RLS teste status='pending' mais le default n'est pas appliqué à temps
-- Solution : utiliser coalesce dans la vérification
drop policy if exists applications_insert_own on public.contributor_applications;

create policy applications_insert_own on public.contributor_applications
  for insert to authenticated with check (
    user_id = auth.uid()
    and coalesce(status, 'pending') = 'pending'
  );

-- ③ Les mises à jour de statut passent uniquement par admin_review_application()
-- (fonction security definer, migration 20261012) : elle n'a pas besoin d'une policy UPDATE,
-- et en accorder une à authenticated serait inutile tant qu'aucune policy ne l'autorise.
-- (Note : « create policy if not exists » n'existe pas en PostgreSQL — cette instruction
-- faisait échouer toute la migration, donc rien ci-dessus n'avait encore été appliqué.)
-- Correction critique : les élèves ne pouvaient voir AUCUNE question.
--
-- Depuis la migration 20261006_admin.sql, la seule policy SELECT sur `public.questions`
-- est réservée aux admins (questions_admin_select). Comme is_admin() est faux pour un
-- élève, Postgres ne lui renvoie aucune ligne — ni via une lecture directe
-- (simulation, réponse courte, rédaction, fiches, duels), ni via pick_questions()
-- (fonction « invoker » : elle respecte les mêmes règles RLS que l'utilisateur connecté).
-- Résultat : tous les modes de jeu semblent vides pour tout le monde sauf le compte admin,
-- sur le site comme dans l'app mobile puisqu'ils utilisent le même projet Supabase.
--
-- Les policies RLS sont combinées en OR : ajouter celle-ci n'enlève rien à
-- questions_admin_select (qui laisse aussi voir les questions désactivées pour l'admin).
drop policy if exists questions_active_select on public.questions;
create policy questions_active_select on public.questions
  for select to authenticated using (active);
-- Demande d'accès contributeur : « La demande n'a pas pu être envoyée ».
-- Cause : user_id référençait public.profiles, or le profil de l'admin est supprimé (20261012)
-- → violation de clé étrangère (23503). On référence directement auth.users.
alter table public.contributor_applications
  drop constraint if exists contributor_applications_user_id_fkey;
alter table public.contributor_applications
  add constraint contributor_applications_user_id_fkey
  foreign key (user_id) references auth.users (id) on delete cascade;

-- La liste admin ne doit plus perdre une demande dont l'auteur n'a pas de profil.
create or replace function public.admin_list_applications()
returns table (user_id uuid, name text, email text, subjects text, school text, message text, created_at timestamptz)
language plpgsql
stable
security definer
set search_path = public
as $$
begin
  if not public.is_admin() then raise exception 'forbidden'; end if;
  return query
    select a.user_id, coalesce(p.name, split_part(u.email::text, '@', 1)), u.email::text,
           a.subjects, a.school, a.message, a.created_at
    from contributor_applications a
    join auth.users u on u.id = a.user_id
    left join profiles p on p.id = a.user_id
    where a.status = 'pending'
    order by a.created_at;
end;
$$;
